let users=[];
class user {
    constructor(name, age, email) {
        this.name = name;
        this.age = age;
        this.email = email;
        this.coins = [];
        this.courses=[];

    }
    login() {
        console.log(`${this.name} has logged in`);
        return this;

    }
    logout() {
        console.log(`${this.name} has logged out`);
        return this;

    }
}
class Moderator extends user {
    constructor(name, age, email, role) {
        super(name, age, email);
        this.role = 'Moderator';
        this.lucoins = 0;
    }
    
    deleteuser(user){
        users=users.filter(u=>{
            return u.email!=user.email;
        })
        addcoin(user)
        {
            lucoins++;
            user.coins.push(lucoins);
            
            return user;
        }
    }
}
class Admin extends Moderator{
    addcourse(user,course){
        user.courses.push(course);
        return user;
    }
    deletecourse(user){
        user.courses.pop();
        return user;

    }
} 
let user1 = new user('priyanka', 21, 'p@gmail.com');
let user2 = new user('Bharti', 22, 'B@gmail.com');
let mod = new Moderator('Berlin', 24, 'b@gmail.com');
let admin=new Admin('Rio',25,'R@gmail.com');
admin.addcourse(user1,'javaScript');
admin.addcourse(user2,'javaScript');
admin.addcourse(user2,'python');

admin.deletecourse(user1);
users=[user1,user2,mod,admin];
console.log(users);

