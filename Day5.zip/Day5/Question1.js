let inputarray=[];
let size=prompt('enter a size of the array',0);
for(let i=0;i<size;i++){
    inputarray[i]=prompt('enter element'+(i+1));
}
console.log(inputarray);
let fil=inputarray.filter(ele=>ele%2!=0).map(ele=>ele*ele*ele);
console.log(fil);











