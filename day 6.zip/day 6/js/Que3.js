console.log('que3');

let text="welcome to my webpage";
alert('what is your name?')
prompt('name')




