console.log("question 2");
let a;
let b= parseInt(prompt("Enter your no."));
for ( a = 1; a < 11; a++) {
    console.log( b + "x" + a + '=' + b*a );
   
   
    
    
}
