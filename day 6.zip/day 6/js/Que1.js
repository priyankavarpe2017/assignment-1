console.log('Que 1) Write a program that will iterate over an array of colors and change the background of the page after 5 sec');
 
let i=0;
let array=new Array("red","pink","violet","blue",'azure','orange', 'skyblue');
function change() {
    document.body.style.background=array[i];
    i++;
    if (i>array.length) {
        i=0;
        
    }
    window.setTimeout("change()",5000);
    
}
window.onload=change();
