function prime(n){
    if(n==1){
        console.log(` ${n} is not a prime number`);
        return false;
    }
    else if(n==2){
        console.log(`${n} is a prime number`);
        return true;
    }
    else{
        for(let x=2;x<n;x++){
            if(n%x==0){
                console.log(` ${n} is not a prime number`);
                return false;
            }
            else{
                console.log(` ${n} is a prime number`);
                return true;
            }
        }
    }
}
let number1
   
=prompt('Enter a number',0);
let ans=prime(number1);
 console.log(ans);