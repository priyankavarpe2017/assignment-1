let que1=(question,yes,no)=>confirm(question)?yes():no();
que1(
    'you have question?',
    ()=>console.log('yes'),
    ()=>console.log('no'),
)