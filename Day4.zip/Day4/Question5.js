let sales=prompt('Enter a sales',0);
 if(sales>=0 && sales<=5000){
    console.log('Rewarded by 2%');
}
else  if(sales>=5001 && sales<=10000){
    console.log('Rewarded by 5%');
}
 else if(sales>=10001 && sales<=20000){
    console.log('Rewarded by 7%');
}
 else if(sales>=20000){
    console.log('Rewarded by 10%');
}
else{
    log('no reward');
}
