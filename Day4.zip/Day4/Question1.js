console.log(`Create a for loop which itreate up to 100 `);
for(let a=0;a<100;a++){
    if(a%3 == 0){
        console.log('fizz');
    }
    if(a%5 == 0){
        console.log('buzz');
    }
    if((a%3!= 0) && (a%5!=0)) {
        console.log('a');
    }
}