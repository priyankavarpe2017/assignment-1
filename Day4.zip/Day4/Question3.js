let grocerylist=['soda','milk','cheese'];
let shoppingBasket=['bread','saltysnack',...grocerylist];
console.log(grocerylist);
console.log(shoppingBasket);