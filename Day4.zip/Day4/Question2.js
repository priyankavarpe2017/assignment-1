//we want to destructure the following object
const student={
    name:"Helsinki",
    age:24,
    projects:{
        diceGame:'The player dice game using JavaScript'
    },
}

const{name,age,projects:diceGame}=student;
console.log(name,age,diceGame);