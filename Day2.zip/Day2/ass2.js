console.log('Que 1)Write a js code which takes input from the user and logs it in console');
// solution of first question

// The alert() Method displays an alert  box with a specied message and an ok button. An alert box is often used if you want  to make sure information comes through to the user


// alert("please fill below information" );


//prompt:Prompt method displays a dialogue box that prompts the user for input .A prompt box is often used if you want the user to input a value before entering a page 
// let login=prompt('Login this page', "creat an accout");


//confirm:confirm method displays a dialog box with a specied message along with and OK and Cancel button .A confirm box is often used if you wnt the user to verify or accept something ... the confirm() method returns true if the user clicked "ok " and false otherwise
// let delet= confirm('do you really want to delete this post?');
// if (delet) {
//     console.log('your post has been deleted');

// }
// else {
//     console.log('your post has not been deleted');

// }
// console.log(delet);

 //soution of second method
// 1) Methods of string
let sample='A string is a sequence of one or more characters that may consist of letters, numbers, or symbols. Strings in JavaScript are primitive data types and immutable, which means they are unchanging.'
let sample2 ='A string is a sequence of '
console.log(sample);
console.log(sample.length);   // The length property returns the length of a string
console.log(sample.toUpperCase()); //converts a string to uppercse letters
console.log(sample.toLowerCase()); //converts a string to lowercse letters
console.log(sample.charAt(49));  //Return the character at the specified index (position)
console.log(sample.charCodeAt(0)); //Return the Unicode of the character at the specified index
console.log(sample.concat(" this is sample text")); //Joins two or more strings, and return a new joined string
console.log(sample.endsWith("text")); //Checks whether a string ends with specified string/characters
console.log(sample.includes('characters')); //check whether the string contanis the specified string/characters
console.log(sample.indexOf('more')); //Returns the position of the last found occurrence of a spcified value in a string
console.log(sample.lastIndexOf("a"));//returns the positionof last found occurrence of a specified value in a string
console.log(sample.match(sample2)); //Searches a string for a match against a regular expression, and return the matches
console.log(sample.replace('this is replace text'));//searches a string for a specified value ,or a regular exp. and return a new string where the specified values are replaced
console.log(sample.slice(13,79));  //Extracts a part of a string and return a new string
console.log(sample. split(" "));  //split a string  into an array of substrings
console.log(sample. startsWith("A")); // check whether the string begins with specified character
console.log(sample. substr(1,5));  //Extracts the characters from a string, beginning at a specified start position, and through the specified number of character
console.log(sample.substring(1,23)); //Extracts the characters from a string, between two specified indices
console.log(sample.trim());  //Removes whitespace from both ends of a string
console.log(sample.valueOf());
0
//2) Methods of Arrays
let array=['Apple', 'Banana',45,79,09,"string",true,false,7856];
console.log(array);
console.log(array.length);
console.log(array.length-1);
console.log(array.indexOf('string'));
console.log(array.indexOf(45));
console.log(array[3]);
console.log(array.shift()); //Remove an item from the beginning of an Array




//3)
console.log("Que 3) Ask the user if he is 21+ and log the value can drink");
let age= prompt("Enter your age:","Age");
alert(`your age is ${age} `);
if(age=>21){
    alert('you are allowed to drink');
    
}
else{
    alert('You are allowed to drink!')
}













































