let input=prompt('Enter the OS name','linux');
let input1="Android 9";
if(input==input1){
    console.log("The OS name is Android and Version is 9");
}
else{
    console.log("The given OS name is not Android and Version is not 9");
}