

let marks=prompt('Enter the marks',0);

console.log(marks == 50? 'Marks are 50 and grade is B' :'marks is not 50');

