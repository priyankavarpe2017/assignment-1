
function evenodd()
{
    let number=prompt('Enter the number','0');
    if(number%2==0)
    {
        console.log("Entered number is even");
    
    }
    else{
      console.log("Entered number is odd");
    
    }

}
let result=evenodd();
console.log(result);